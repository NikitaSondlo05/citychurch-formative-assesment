package za.citychurch.jms;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;
import javax.inject.Inject;
import za.citychurch.store.NotificationStore;
import za.citychurch.websocket.NotificationEndpoint;

// Question 5-JMS to Websocket Integration 
@MessageDriven(activationConfig = {
        @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Topic"),
        @ActivationConfigProperty(propertyName = "destinationLookup", propertyValue = "jms/ChurchNotifications"),
        @ActivationConfigProperty(propertyName = "subscriptionDurability", propertyValue = "Durable"),
        @ActivationConfigProperty(propertyName = "subscriptionName", propertyValue = "citychurch-websocket-bridge")
})
public class NotificationConsumer implements MessageListener {
    @Inject private NotificationStore notifications;

    @Override
    public void onMessage(Message message) {
        if (message instanceof TextMessage) {
            try {
                TextMessage textMessage = (TextMessage) message;
                String notification = textMessage.getText();
                notifications.add(notification);
                NotificationEndpoint.broadcastMessage(notification);
            } catch (Exception exception) {
                throw new IllegalStateException("Could not process church notification", exception);
            }
        }
    }
}
