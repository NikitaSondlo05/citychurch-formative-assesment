package za.citychurch.jms;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.jms.JMSContext;
import javax.jms.JMSConnectionFactory;
import javax.jms.Topic;
import javax.annotation.Resource;
// Question 4- JMS publisher
@Stateless
public class NotificationPublisher {
    @Inject
    @JMSConnectionFactory("jms/ChurchConnectionFactory")
    private JMSContext context;

    @Resource(lookup = "jms/ChurchNotifications")
    private Topic notificationTopic;

    public void publish(String notification) {
        
        context.createProducer().setDeliveryMode(javax.jms.DeliveryMode.PERSISTENT)
                .send(notificationTopic, notification);
    }
}
