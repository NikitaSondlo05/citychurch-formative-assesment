package za.citychurch.listener;

import javax.inject.Inject;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import za.citychurch.store.NotificationStore;


@WebListener
public class ApplicationStartupListener implements ServletContextListener {
    @Inject private NotificationStore notifications;

    @Override
    public void contextInitialized(ServletContextEvent event) {
        event.getServletContext().setAttribute("notificationStore", notifications);
    }
}
