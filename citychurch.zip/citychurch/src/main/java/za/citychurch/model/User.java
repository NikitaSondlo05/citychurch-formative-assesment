package za.citychurch.model;

import java.io.Serializable;
// Question 6- user class
//user stored
public final class User implements Serializable {
    private static final long serialVersionUID = 1L;

    public static final String MEMBER = "MEMBER";
    public static final String CHURCH_LEADER = "CHURCH_LEADER";

    private final String username;
    private final String passwordHash;
    private final String role;

    public User(String username, String passwordHash, String role) {
        this.username = username;
        this.passwordHash = passwordHash;
        this.role = role;
    }

    public String getUsername() { return username; }
    public String getPasswordHash() { return passwordHash; }
    public String getRole() { return role; }
    public boolean isChurchLeader() { return CHURCH_LEADER.equals(role); }
}
