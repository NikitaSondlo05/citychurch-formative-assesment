package za.citychurch.servlet;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import za.citychurch.model.User;
import za.citychurch.store.InMemoryUserStore;
import za.citychurch.util.PasswordHasher;

import java.io.IOException;
import java.util.Optional;
//question 2- login servlet
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    @Inject private InMemoryUserStore users;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username") == null ? "" : request.getParameter("username").trim();
        String password = request.getParameter("password");
        if (!username.matches("[A-Za-z0-9_.-]{3,40}") || password == null || password.trim().isEmpty()) {
            fail(request, response, "Username and password are required.");
            return;
        }
        Optional<User> user = users.find(username);
        if (!user.isPresent() || !user.get().getPasswordHash().equals(PasswordHasher.hash(password))) {
            fail(request, response, "Invalid username or password.");
            return;
        }
        request.changeSessionId(); // protects an existing session from fixation
        HttpSession session = request.getSession(true);
        session.setAttribute("user", user.get());
        response.sendRedirect(request.getContextPath() + "/home.jsp");
    }

    private void fail(HttpServletRequest request, HttpServletResponse response, String message)
            throws ServletException, IOException {
        request.setAttribute("error", message);
        request.getRequestDispatcher("/login.jsp").forward(request, response);
    }
}
