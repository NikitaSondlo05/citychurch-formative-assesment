package za.citychurch.servlet;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.citychurch.jms.NotificationPublisher;
import za.citychurch.model.User;

import java.io.IOException;
// question 10- Notification page
@WebServlet("/publish-notification")
public class PublishNotificationServlet extends HttpServlet {
    @EJB private NotificationPublisher publisher;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        User user = (User) request.getSession().getAttribute("user");
        if (user == null || !user.isChurchLeader()) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Church Leaders only.");
            return;
        }
        String message = request.getParameter("message") == null ? "" : request.getParameter("message").trim();
        if (message.isEmpty()) {
            request.setAttribute("error", "A notification message is required.");
            request.getRequestDispatcher("/notification.jsp").forward(request, response);
            return;
        }
        publisher.publish(message);
        request.setAttribute("success", "Notification published.");
        request.getRequestDispatcher("/notification.jsp").forward(request, response);
    }
}
