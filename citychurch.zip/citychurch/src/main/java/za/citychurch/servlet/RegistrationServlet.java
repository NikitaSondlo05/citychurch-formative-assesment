package za.citychurch.servlet;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.citychurch.model.User;
import za.citychurch.store.InMemoryUserStore;
import za.citychurch.util.PasswordHasher;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
// question 1-user registration servlet
@WebServlet("/register")
public class RegistrationServlet extends HttpServlet {
    private static final Set<String> ALLOWED_ROLES = Collections.unmodifiableSet(
            new HashSet<>(Arrays.asList(User.MEMBER, User.CHURCH_LEADER)));
    @Inject private InMemoryUserStore users;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = value(request.getParameter("username"));
        String password = request.getParameter("password");
        String role = value(request.getParameter("role"));

        if (!username.matches("[A-Za-z0-9_.-]{3,40}") || password == null || password.trim().isEmpty() || !ALLOWED_ROLES.contains(role)) {
            request.setAttribute("error", "Use a 3-40 character username (letters, numbers, ., _ or -), password and valid role.");
            request.getRequestDispatcher("/registration.jsp").forward(request, response);
            return;
        }
        if (!users.register(new User(username, PasswordHasher.hash(password), role))) {
            request.setAttribute("error", "That username is already registered.");
            request.getRequestDispatcher("/registration.jsp").forward(request, response);
            return;
        }
        request.setAttribute("success", "Registration successful. Please sign in.");
        request.getRequestDispatcher("/login.jsp").forward(request, response);
    }

    private static String value(String input) { return input == null ? "" : input.trim(); }
}
