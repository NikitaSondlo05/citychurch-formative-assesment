package za.citychurch.store;

import javax.enterprise.context.ApplicationScoped;
import za.citychurch.model.User;

import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
// question 1 -user registation  servlet
@ApplicationScoped
public class InMemoryUserStore {
    private final ConcurrentMap<String, User> users = new ConcurrentHashMap<>();

   //reject duplicate
    public boolean register(User user) {
        return users.putIfAbsent(user.getUsername(), user) == null;
    }

    public Optional<User> find(String username) {
        return Optional.ofNullable(users.get(username));
    }
}
