package za.citychurch.store;

import javax.enterprise.context.ApplicationScoped;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


@ApplicationScoped
public class NotificationStore {
    private static final int MAX_NOTIFICATIONS = 100;
    private final List<String> notifications = new ArrayList<>();

    public synchronized void add(String notification) {
        notifications.add(0, notification);
        if (notifications.size() > MAX_NOTIFICATIONS) {
            notifications.remove(notifications.size() - 1);
        }
    }

    public synchronized List<String> all() {
        return Collections.unmodifiableList(new ArrayList<>(notifications));
    }
}
