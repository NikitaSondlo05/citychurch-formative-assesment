package za.citychurch.websocket;

import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import java.io.IOException;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

//question 3-used for push notifications
@ServerEndpoint("/notifications")
public class NotificationEndpoint {
    private static final Set<Session> CLIENTS = ConcurrentHashMap.newKeySet();

    @OnOpen
    public void onOpen(Session session) {
        CLIENTS.add(session);
    }

    @OnClose
    public void onClose(Session session) {
        CLIENTS.remove(session);
    }

    @OnError
    public void onError(Session session, Throwable error) {
        CLIENTS.remove(session);
    }

    /** Sends one already-validated notification to every open WebSocket connection. */
    public static void broadcastMessage(String message) {
        for (Session client : CLIENTS) {
            if (client.isOpen()) {
                client.getAsyncRemote().sendText(message);
            } else {
                CLIENTS.remove(client);
            }
        }
    }
}
