<%@ page import="za.citychurch.model.User,za.citychurch.store.NotificationStore" %>
<%@ page contentType="text/html; charset=UTF-8" %>
<% User currentUser = (User) session.getAttribute("user");
   if (currentUser == null) { response.sendRedirect(request.getContextPath() + "/login.jsp"); return; }
   NotificationStore notificationStore = (NotificationStore) application.getAttribute("notificationStore"); %>
<!DOCTYPE html>
<html><head><title>City Church | Home</title></head>
<body>
    <h1>Welcome, <%= currentUser.getUsername() %></h1>
    <% if (currentUser.isChurchLeader()) { %><p><a href="notification.jsp">Publish a notification</a></p><% } %>
    <form method="post" action="<%= request.getContextPath() %>/logout"><button>Sign out</button></form>
    <h2>Church notifications</h2>
    <ul id="notifications">
        <% if (notificationStore != null) for (String item : notificationStore.all()) { %>
            <li><%= item %></li>
        <% } %>
    </ul>
    <script>
        const protocol = location.protocol === 'https:' ? 'wss://' : 'ws://';
        const socket = new WebSocket(protocol + location.host + '<%= request.getContextPath() %>/notifications');
        socket.onmessage = event => {
            const item = document.createElement('li');
            item.textContent = event.data; // textContent prevents HTML injection
            document.getElementById('notifications').prepend(item);
        };
    </script>
</body></html>
