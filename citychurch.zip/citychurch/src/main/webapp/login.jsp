<%@ page contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html><head><title>City Church | Sign in</title></head>
<body>
    <h1>Sign in</h1>
    <% if (request.getAttribute("error") != null) { %><p role="alert"><%= request.getAttribute("error") %></p><% } %>
    <% if (request.getAttribute("success") != null) { %><p><%= request.getAttribute("success") %></p><% } %>
    <form method="post" action="<%= request.getContextPath() %>/login">
        <label>Username <input name="username" required autocomplete="username"></label><br>
        <label>Password <input type="password" name="password" required autocomplete="current-password"></label><br>
        <button type="submit">Sign in</button>
    </form>
    <p>New member? <a href="registration.jsp">Register</a></p>
</body></html>
