<%@ page import="za.citychurch.model.User" %>
<%@ page contentType="text/html; charset=UTF-8" %>
<% User currentUser = (User) session.getAttribute("user");
   if (currentUser == null) { response.sendRedirect(request.getContextPath() + "/login.jsp"); return; }
   if (!currentUser.isChurchLeader()) { response.sendError(403, "Church Leaders only."); return; } %>
<!DOCTYPE html>
<html><head><title>City Church | Publish notification</title></head>
<body>
    <h1>Publish a church notification</h1>
    <% if (request.getAttribute("error") != null) { %><p role="alert"><%= request.getAttribute("error") %></p><% } %>
    <% if (request.getAttribute("success") != null) { %><p><%= request.getAttribute("success") %></p><% } %>
    <form method="post" action="<%= request.getContextPath() %>/publish-notification">
        <label>Announcement<br><textarea name="message" required maxlength="1000" rows="5" cols="60"></textarea></label><br>
        <button type="submit">Send notification</button>
    </form>
    <p><a href="home.jsp">Back to home</a></p>
</body></html>
