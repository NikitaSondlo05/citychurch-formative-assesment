<%@ page contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html><head><title>City Church | Register</title></head>
<body>
    <h1>Create an account</h1>
    <% if (request.getAttribute("error") != null) { %><p role="alert"><%= request.getAttribute("error") %></p><% } %>
    <form method="post" action="<%= request.getContextPath() %>/register">
        <label>Username <input name="username" required maxlength="40" autocomplete="username"></label><br>
        <label>Password <input type="password" name="password" required autocomplete="new-password"></label><br>
        <label>Role
            <select name="role" required>
                <option value="MEMBER">Member</option>
                <option value="CHURCH_LEADER">Church Leader</option>
            </select>
        </label><br>
        <button type="submit">Register</button>
    </form>
    <p>Already registered? <a href="login.jsp">Sign in</a></p>
</body></html>
